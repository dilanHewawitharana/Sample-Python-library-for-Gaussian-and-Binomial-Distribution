from setuptools import setup

setup(name='dsh_distributions',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['dsh_distributions'],
      author = 'Dilan Sarith Hewawitharana',
      author_email = 'dshewawitharana@gmail.com',
      zip_safe=False)
